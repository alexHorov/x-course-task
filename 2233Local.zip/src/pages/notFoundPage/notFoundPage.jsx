import React from 'react';

export function NotFoundPage() {
  return <h1 className="empty-page">Щось пішло не так (404) 🕵️</h1>;
}
