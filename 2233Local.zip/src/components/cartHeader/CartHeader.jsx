import React from "react";
import "./style.scss";

export const CartHeader = () => {
  return (
    <header className="cart-header">
      <div className="cart-header__title">Найменування</div>
      <div className="cart-header__count">Кількість</div>
      <div className="cart-header__cost">Вартість</div>
    </header>
  );
};
