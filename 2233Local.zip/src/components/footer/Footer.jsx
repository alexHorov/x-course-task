import { Link, NavLink } from 'react-router-dom';
import { CustomLink } from 'components/customLink/CustomLink';
import avatarImage from 'assets/avatar.png';
import cartImage from 'assets/cart.svg';
import 'components/footer/footer.css';
import React from 'react';

function Footer() {
  return (
    <div className="header">
      <div className="header__left-block">
        <CustomLink to="/">
          <h2>JS BAND/YOUR FULL NAME</h2>
        </CustomLink>
      </div>
      <div className="header__right-block">
        <NavLink to="/cart" href="http://" className="header__cart">
          <img src={cartImage} alt="cart" />
        </NavLink>
        <NavLink to="singIn">
          <button to="singIn" className="sing_out">
            Sing-Out
          </button>
        </NavLink>
        <NavLink to="singIn" href="http://" className="">
          <img className="header__avatar" src={avatarImage} alt="avatar" />
        </NavLink>
        <p className="header__userName">Username</p>
      </div>
    </div>
  );
}

export { Footer };
