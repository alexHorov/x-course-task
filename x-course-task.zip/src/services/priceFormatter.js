const formatPrice = new Intl.NumberFormat();

export default formatPrice.format;