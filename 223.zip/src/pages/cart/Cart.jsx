// import { useEffect, useState } from "react";
import React from 'react';
import { Spinner } from 'components/spinner/Spinner';

function Cart() {
  return (
    <div className="wrapper">
      <h1>Hello in Cart </h1>
      <Spinner />
    </div>
  );
}

export { Cart };
