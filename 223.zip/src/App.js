import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, } from 'react-router-dom';
import { LocalStorageService, LS_KEYS } from 'services/localStorage';
import { UserProvider } from 'hooks/useUserInfo';
import { getAllBooks } from 'api.js';
import { ScrollToTop } from 'services/scrollToTop';
import { Layout } from "pages/layout/Layout"
import { BooksCatalog } from 'pages/booksCatalog/BooksCatalog'
import { SingleBook } from 'pages/singleBook/SingleBook';
import { SingIn } from 'pages/singIn/SingIn';
import { Cart } from 'pages/cart/Cart';
import { NotFoundPage } from 'pages/notFoundPage/notFoundPage';




function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem('isLoggedIn') === 'true')
  const [userName, setUserName] = useState(localStorage.getItem('userName'));
  const [booksCatalog, setBooksCatalog] = useState([]);

  useEffect(() => {

    getAllBooks().then((data) => {
      setBooksCatalog(data.books);
    });

  }, []);


  return (
    <UserProvider
      value={{
        booksCatalog,
        userName,
        setUserName: (i) => setUserName(i),
        isLoggedIn,
        setIsLoggedIn: (f) => setIsLoggedIn(f),
      }}
    >
      <BrowserRouter>
        <ScrollToTop />

        <Routes>

          <Route path="/" element={<Layout />} >
            <Route index element={<SingIn />} />
            <Route path="cart" element={<Cart />} />
            <Route path="booksCatalog" element={<BooksCatalog />} />
            <Route path="booksCatalog/:idBook" element={<SingleBook />} />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </UserProvider>
  );
}

export default App;
