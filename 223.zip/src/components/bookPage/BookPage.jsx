import notFountImage from 'assets/imageNotFound.png';
import countUp from 'assets/count-up.svg';
import countDown from 'assets/count-down.svg';
import 'components/bookPage/bookPage.css';
import React from 'react';

function BookPage(book) {
  const { id, author, price, image, title, description } = book;

  return (
    <div className="book__content">
      <div className="book__info">
        <div className="book__info-img">
          <img src={image !== '' ? image : notFountImage} alt="book Picture" />
        </div>
        <div className="book__info-descr">
          <h2>{title}</h2>
          <p> Book author: {author}</p>
          <p> Book level</p>
          <p> Book tags</p>
        </div>
        <div className="book__info-price">
          <div className="book__price-price">
            <h3>Price, $</h3>
            <p id="price">{price}</p>
          </div>
          <div className="book__info-count">
            <h3>Count</h3>
            <div className="count">
              <div className="count__box">
                <input
                  type="number"
                  className="count__input"
                  min="1"
                  max="42"
                  value="1"
                />
              </div>
              <div className="count__controls">
                <button type="button" className="count__up">
                  <img className="up" src={countUp} alt="Increase" />
                </button>
                <button type="button" className="count__down">
                  <img className="down" src={countDown} alt="Decrease" />
                </button>
              </div>
            </div>
          </div>
          <div className="book__price--total-price">
            <h3>Total price</h3>
            <p id="sum">10.5</p>
          </div>
          <div className="book__info-button">
            <button id={id} className="addToCart">
              Add to cart
            </button>
          </div>
        </div>
      </div>

      <div className="book__info-text">
        <p>{description}</p>
      </div>
    </div>
  );
}
export { BookPage };
