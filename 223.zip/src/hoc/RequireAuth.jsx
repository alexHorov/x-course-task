import { Navigate, useLocation } from 'react-router-dom';
import { useUserInfo } from 'hooks/useUserInfo';

const RequireAuth = ({ children }) => {
  const { isLoggedIn } = useUserInfo();
  const location = useLocation();

  if (!isLoggedIn) {
    return <Navigate to="/" state={{ from: location }} />;
  }

  return children;
};

export { RequireAuth };
